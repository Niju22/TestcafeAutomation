import { Selector, t } from "testcafe";
import getElementsByXPath from '../Utility/xpath-selector'

class CartPage {
    clickTocart: Selector;
    deleteElement: Selector;
    clickBook: Selector;
    clickAddtocart: Selector;
    constructor() {
        this.deleteElement = Selector(getElementsByXPath("//mat-icon[text()='delete']"));
        this.clickBook = Selector("a[aria-label='Book title']");
        this.clickTocart = Selector(getElementsByXPath("//mat-icon[@matbadgecolor='warn']"));
        this.clickAddtocart = Selector(getElementsByXPath("//span[normalize-space(text())='Add to Cart']"));
    }

    async deleteButton() {
        await t.click(this.deleteElement);
    }
    async clickSelectedBook() {
        await t.click(this.clickBook);
    }
    async clickCartIcon() {
        await t.click(this.clickTocart);
    }
    async clickAddtocartButton() {
        await t.click(this.clickAddtocart);
    }
}
export default new CartPage();