import { Selector,t } from "testcafe";

class SearchBookPage{

    searchInput:Selector;

    constructor(){
        this.searchInput = Selector("input[type='search']");
    }

    async SearchBook(bookName:string)
    {
        await t.typeText(this.searchInput,bookName)
                .pressKey('down')
                .pressKey('enter')

    }

}

export default new SearchBookPage();