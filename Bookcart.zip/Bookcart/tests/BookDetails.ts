import { Selector } from "testcafe";
import jsonData from '../TestData/CartData.json';
import CartPage from "../Pages/CartPage";
import SearchBookPage from "../Pages/SearchBookPage";

fixture("View Book Details").skipJsErrors();

jsonData.book.forEach(j => {

    test("View Book Details on Cart Page", async (t) => {

        //Navigate to Url
        await t.navigateTo("https://bookcart.azurewebsites.net/");
        await t.maximizeWindow();

        //Search for Book and validating searched book
        SearchBookPage.SearchBook(j.name)
        const book = await Selector("strong").withText(j.result);
        await t.expect(book.exists).ok();

        //verify the Author name
        CartPage.clickSelectedBook();
        const authorName = Selector("td").withText(j.authorname);
        await t.expect(authorName.exists).ok();

        //verify the Book Category
        const bookCategory = Selector("td").withText(j.bookcategory);
        await t.expect(bookCategory.exists).ok();

        //verify the Book Price
        const bookPrice = Selector("td").withText(j.bookprice);
        await t.expect(bookPrice.exists).ok();
    })
})