import { Selector } from "testcafe";
import jsonData from '../TestData/CartData.json';
import CartPage from "../Pages/CartPage";
import SearchBookPage from "../Pages/SearchBookPage";

fixture("Delete a Book").skipJsErrors();

jsonData.book.forEach(j => {

    test("Delete Added Book from Cart Page", async (t) => {

        //Navigate to Url
        await t.navigateTo("https://bookcart.azurewebsites.net/");
        await t.maximizeWindow();

        //Search for Book and validating searched book
        SearchBookPage.SearchBook(j.name)
        const book = await Selector("strong").withText(j.result);
        await t.expect(book.exists).ok();

        //Add Book to Cart Page
        CartPage.clickAddtocartButton();

        //Go to Shopping Cart section.
        CartPage.clickCartIcon();

        //Verify Added book is on Shopping cart page or not
        const addedbook = await Selector('a').withText(j.name);
        await t.expect(addedbook.exists).ok();

        //Deleting Added Book in cart page
        CartPage.deleteButton();

        //Verify Your shopping cart is empty message is displayed
        const emptycart = await Selector('mat-card-title').withText("Your shopping cart is empty.");
        await t.expect(emptycart.exists).ok();

    })
})