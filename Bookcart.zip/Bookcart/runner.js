const createTestCafe = require('testcafe');

let testcafe = null;

createTestCafe('localhost',1337,1338)
.then(tc => {
    testcafe=tc;
    const runner = testcafe.createRunner();

    return runner
    .src('tests/DeleteCart.ts','tests/BookDetails.ts')
    .browsers(['chrome'])
    .tsConfigPath('./tsconfig.json')
    .reporter('allure')
    .run();
}).then(failedCount =>{
    console.log('Testsfailed' + failedCount);

    testcafe.close();
}).catch(error =>{
    console.error(error);
})