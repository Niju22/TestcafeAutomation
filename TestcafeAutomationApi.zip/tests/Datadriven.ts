import * as ExcelJS from 'exceljs';
import { fixture,test,t } from 'testcafe';

fixture("DDT").page("https://testautomationpractice.blogspot.com/").skipJsErrors();

test('Read Data from Excel', async (t) =>{

    const filePath = 'C:/Users/zadmin/Desktop/Testcafeautomation/Testdata/EmployeeData.xlsx';

    const workBook = new ExcelJS.Workbook();
    await workBook.xlsx.readFile(filePath);
    const workSheet = workBook.getWorksheet('Employee Data');

    if(!workSheet){
        throw new Error("Work Sheet Employee Data not foumd in the excel file");
    }

    for(let i=2;i<=workSheet.rowCount;i++)
    {
        const row = workSheet.getRow(i);

        const firstName = row.getCell('A').value?.toString() || '';
        const lastName = row.getCell('B').value?.toString() || '';
        const email = row.getCell('C').value?.toString() || '';

        await t.maximizeWindow()
            .typeText("#name", firstName + " " + lastName,{replace:true})
            .typeText('#email',email,{replace:true})
            .wait(3000);
    }

});