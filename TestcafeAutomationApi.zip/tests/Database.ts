// import * as sql from 'mssql';
import { fixture,test,t } from 'testcafe';
import * as ExcelJS from 'exceljs';
import* as mysql from 'mysql2/promise'

//Code to connect to database
const config = {
    server:'localhost:3306',
    user:'root',
    password:'Pass@123',
    database:'Testing',
    options:{
        encrypt:true, //Use Encryption if needed
        trustServerCertificate:true //Set true if self sign is required
    }
};

async function fetchDataFromSQL(query: string):Promise<any>{
    let connection

    try{
          connection = await mysql.createConnection(config);
                //const result = await pool.request().query(query);
                const [rows] = await connection.execute(query);
                return rows;
        
                //return result.recordset;
        // const pool = await sql.connect(config);
        // const result = await pool.request().query(query);

        // return result.recordset;
    } catch(err){
        console.log('SQL error' + err);
        throw err;
    }
}


fixture("SQLTest").page("https://testautomationpractice.blogspot.com/").skipJsErrors();

test("Read Data from SQL and use in TestCafe test",async (t) => {

    const query = 'select * from Emplyees';
    const data = await fetchDataFromSQL(query);

    for(const row of data)
    {
        console.log("FirstName : " + row.FirstName + " LastName : " + row.LastName + " Email Id : " + row.Email);
    }

    const workBook = new ExcelJS.Workbook();
    const workSheet = workBook.addWorksheet('Employee Data');

    //Add headers
    workSheet.columns = [
        {header:'First Name',key:'FirstName'},
        {header:'Last Name',key:'LastName'},
        {header:'Email',key:'Email'}
    ];
    
    //Add/INSERT rows to the worksheet
    data.forEach(row =>{
        workSheet.addRow({
            firstName: row.FirstName,
            lastName:row.LastName,
            email:row.Email
        });
    });

    //Save the excel at the respective path
    const filePath = 'C:/Users/zadmin/Desktop/Testcafeautomation/Testdata/EmployeeData.xlsx';
    await workBook.xlsx.writeFile(filePath);


    console.log("Excel Data file is created at " + filePath);

    for(const row of data)
    {
        await t.maximizeWindow()
            .typeText("#name", row.FirstName+ " "+row.LastName,{replace:true})
            .typeText('#email',row.Email,{replace:true})

            await t.wait(3000);
    }
})