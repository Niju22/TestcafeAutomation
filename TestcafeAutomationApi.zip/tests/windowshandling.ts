import { Selector } from "testcafe";
import getElementsByXPath from './Xpathdocument';

fixture("Windows Handling").page("https://practice.sdetunicorns.com/")

test("Windows Handling Test",async (t)=>{
    await t.maximizeWindow();
    const homepage=await t.getCurrentWindow();
    await t.click("a#contact-us");
    await t.maximizeWindow();
    await t.typeText("input[type='email']","test@example.com");
    await t.closeWindow();
    // await t.switchToWindow(homepage);
    // await t.switchToParentWindow();  //back

    const shop=await getElementsByXPath("(//a[text()='Shop'])[1]");
    await t.click(shop);
    await t.typeText("input.search-field","Converse");
    await t.click("button[type='submit']");


})