import * as sql from 'mssql';
import* as mysql from 'mysql2/promise'
import { fixture,test,t } from 'testcafe';
import * as ExcelJS from 'exceljs';

//Code to connect to database
const config = {
    server:'localhost:3306',
    user:'root',
    password:'Pass@123',
    database:'Testing',
    options:{
        encrypt:true, //Use Encryption if needed
        trustServerCertificate:true //Set true if self sign is required
    }
};

async function fetchDataFromSQL(query: string):Promise<any>{
let connection
    try{
        connection = await mysql.createConnection(config);
        //const result = await pool.request().query(query);
        const [rows] = await connection.execute(query);
        return rows;

        //return result.recordset;
    } catch(err){
        console.log('SQL error' + err);
        throw err;
    }
}


fixture("SQLTest").page("https://testautomationpractice.blogspot.com/").skipJsErrors();

test("Read Data from SQL and use in TestCafe test",async (t) => {

    const query = 'select * from Employees';
    const data = await fetchDataFromSQL(query);

    for(const row of data)
    {
        console.log("FirstName : " + row.firstName + " LastName : " + row.lastName + " Email Id : " + row.email);
    }

    const workBook = new ExcelJS.Workbook();
    const workSheet = workBook.addWorksheet('Employee Data');

    //Add headers
    workSheet.columns = [
        {header:'First Name',key:'firstName'},
        {header:'Last Name',key:'lastName'},
        {header:'Email',key:'email'}
    ];
    
    //Add/INSERT rows to the worksheet
    data.forEach(row =>{
        workSheet.addRow({
            firstName: row.firstName,
            lastName:row.lastName,
            email:row.email
        });
    });

    //Save the excel at the respective path
    const filePath = 'C:/Users/zadmin/Downloads/typescript-codes-main/typescript-codes-main/TestCafeLatest/EmployeeData1.xlsx';
    await workBook.xlsx.writeFile(filePath);


    console.log("Excel Data file is created at " + filePath);

    for(const row of data)
    {
        await t.maximizeWindow()
            .typeText("#name", row.firstName+ " "+row.lastName,{replace:true})
            .typeText('#email',row.email,{replace:true})

            await t.wait(3000);
    }
})