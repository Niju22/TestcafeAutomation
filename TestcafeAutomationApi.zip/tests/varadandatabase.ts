import * as sql from 'mssql';
import { fixture,test,t } from 'testcafe';
import * as ExcelJS from 'exceljs';

//Code to connect to database
const config = {
    server:'localhost',
    user:'SA',
    password:'VardhanTesting84',
    database:'Testing',
    options:{
        encrypt:true, //Use Encryption if needed
        trustServerCertificate:true //Set true if self sign is required
    }
};

async function fetchDataFromSQL(query: string):Promise<any>{

    try{
        const pool = await sql.connect(config);
        const result = await pool.request().query(query);

        return result.recordset;
    } catch(err){
        console.log('SQL error' + err);
        throw err;
    }
}


fixture("SQLTest").page("https://testautomationpractice.blogspot.com/").skipJsErrors();

test("Read Data from SQL and use in TestCafe test",async (t) => {

    const query = 'select * from Employees';
    const data = await fetchDataFromSQL(query);

    for(const row of data)
    {
        console.log("FirstName : " + row.firstName + " LastName : " + row.lastName + " Email Id : " + row.email);
    }

    const workBook = new ExcelJS.Workbook();
    const workSheet = workBook.addWorksheet('Employee Data');

    //Add headers
    workSheet.columns = [
        {header:'First Name',key:'firstName'},
        {header:'Last Name',key:'lastName'},
        {header:'Email',key:'email'}
    ];
    
    //Add/INSERT rows to the worksheet
    data.forEach(row =>{
        workSheet.addRow({
            firstName: row.firstName,
            lastName:row.lastName,
            email:row.email
        });
    });

    //Save the excel at the respective path
    const filePath = '/Users/apple/Desktop/TestCafeLatest/EmployeeData.xlsx';
    await workBook.xlsx.writeFile(filePath);


    console.log("Excel Data file is created at " + filePath);

    for(const row of data)
    {
        await t.maximizeWindow()
            .typeText("#name", row.firstName+ " "+row.lastName,{replace:true})
            .typeText('#email',row.email,{replace:true})

            await t.wait(3000);
    }
})



//===============

//installing mssql command npm install mssql

// CREATE DATABASE Testing
//console.log(config.database);
//https://testcafe.io/documentation/402837/guides/basic-guides/assertions
//https://jsonpath.com/ 
//https://jsonpathfinder.com/
 

 
// CREATE TABLE Employees(
//     firstName VARCHAR(50),
//     lastName VARCHAR(50),
//     email VARCHAR(100) UNIQUE,
// );
 
// SELECT * FROM Employees
 
// INSERT INTO Employees(firstName,lastName,email) VALUES
// ('Sachin','Tendulkar','sachin.tendulkar@gmail.com'),
// ('Virat','Kohli','virat.kohli.com')