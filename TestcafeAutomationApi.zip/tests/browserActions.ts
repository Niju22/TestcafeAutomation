import { Selector } from "testcafe";
fixture("Browser Actions").skipJsErrors();

test("Browser action",async (t)=>{
    await t.navigateTo("https://testautomationpractice.blogspot.com/"); //Navigation
   
    await t.resizeWindow(1024,960); //resize window
    await t.maximizeWindow(); //maximize

   const scrollAlert=await Selector("h2").withText("Alerts & Popups");
   await t.scrollIntoView(scrollAlert);


    const simpleAlert=await Selector("button#alertBtn");  //simple Alert
    await t.setNativeDialogHandler(() => true);   
    await t.click(simpleAlert);

    const confirmAlert=await Selector("button#confirmBtn"); //confirm Alert
    await t.setNativeDialogHandler(()=>true);
    await t.click(confirmAlert);

    // const confirmAlert=await Selector("button#confirmBtn"); //confirm Alert for cancel
    // await t.setNativeDialogHandler(()=>false);
    // await t.click(confirmAlert);

    const promptAlert=Selector("button#promptBtn");
    await t.setNativeDialogHandler(()=>false);
    await t.click(promptAlert);
    // await t.pressKey("delete");
    // await t.typeText(promptAlert,"Testing Prompt Alert");
    await t.wait(5000);

   
})