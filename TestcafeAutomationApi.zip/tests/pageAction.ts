import { Selector } from "testcafe";
fixture("Page action").page("https://testautomationpractice.blogspot.com/").skipJsErrors()

test("Page action method test",async(t)=>{

    await t.maximizeWindow();

   const name=await Selector('input#name');
   await t.typeText(name,"David Niju");

   const mailid=await Selector('input#email');
   await t.typeText(mailid,"sfdavid@example.com");

   const phone=await Selector('input#phone');
   await t.typeText(phone,"123456");
   await t.pressKey('space');  //press key
   await t.typeText(phone,"789");

   const address=await Selector("textarea#textarea");       //typetext
   await t.typeText(address,"12/37,South Street,Testing address");
   await t.selectText(address); //select text
   await t.pressKey('delete');
   await t.typeText(address,"Testcafe");


   const gender=await Selector("input#male");       //click
   await t.click(gender);

  const days=await Selector("input#tuesday");
  await t.click(days);

  const country=await Selector("select#country");
  await t.click(country);
  await t.click("option[value='usa']");

  const colors=await Selector("option[value='blue']");
  await t.click(colors);
  
  const animal=await Selector("option[value='lion']");
  await t.click(animal);

 const datepicker= await Selector("input#datepicker");
 await t.click(datepicker);
 await t.hover("a[data-date='22']");  //hover
 await t.click("a[data-date='22']");

const doubleclick= await Selector("input#field1");
await t.doubleClick(doubleclick);  //double click
await t.selectText(doubleclick);
await t.pressKey('delete')
await t.typeText(doubleclick,"Testing");

const rightClicks=await Selector("button[ondblclick='myFunction1()']");  //right click
await t.rightClick(rightClicks);


 const scrolltohover=await Selector("button.dropbtn"); //scroll into element
 await t.scrollIntoView(scrolltohover);
 await t.hover(scrolltohover);
 const hoverelement=await Selector('a').withText("Mobiles");
 await t.click(hoverelement);

 const scrolltodrag=await Selector('p').withText("Drag me to my target");
 await t.scrollIntoView(scrolltodrag);
 await t.dragToElement("div#draggable","div#droppable");











})