import {t,test,fixture} from 'testcafe';

fixture("API Testing - POST Method");

test("POST Request", async (t) =>{

    //sent request with get method and stored the response into a response variable.
    const response = await t.request.post("https://jsonplaceholder.typicode.com/posts",{
        body:{
            title:"testing",
            body:"automation TestCafe",
            userId:1
        }
    });

    //Validate the response
    await t.expect(response.status).eql(201);

    console.log(response.body);

    const reponseBody = typeof response.body == 'string' ? JSON.parse(response.body) : response.body;
    
    await t.expect(reponseBody.title).eql("testing");
    await t.expect(reponseBody.body).eql("automation TestCafe");
    await t.expect(reponseBody.userId).eql(1);
    await t.expect(reponseBody.id).eql(101);

    //console.log("Response Body :" + response);

})