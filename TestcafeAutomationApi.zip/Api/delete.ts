import {t,test,fixture} from 'testcafe';

fixture("API Testing - POST Method");

test("POST Request", async (t) =>{

    //sent request with get method and stored the response into a response variable.
    const response = await t.request.delete("https://jsonplaceholder.typicode.com/posts");

    //Validate the response
    await t.expect(response.status).eql(200);

    console.log(response.body);

    //const reponseBody = typeof response.body == 'string' ? JSON.parse(response.body) : response.body;
    
    // await t.expect(reponseBody.title).eql("testing");
    // await t.expect(reponseBody.body).eql("automation Test Cafe");
    // await t.expect(reponseBody.userId).eql(1);
    // await t.expect(reponseBody.id).eql(1);

    //console.log("Response Body :" + response);

})