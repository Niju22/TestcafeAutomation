import {t,test,fixture} from 'testcafe';

fixture("API Testing - POST Method");

test("POST Request", async (t) =>{

    //sent request with get method and stored the response into a response variable.
    const response = await t.request.post("https://jsonplaceholder.typicode.com/posts",{
        headers:{
            'content-type':'application/json',
            'Authorization':'Bearer YOUR_ACCESS_TOKEN'
        },
        body:{
            title:"testing",
            body:"automation Test Cafe",
            userId:1
        }
    });

    //Validate the response
    await t.expect(response.status).eql(201);

    console.log(response.body);

    const reponseBody = typeof response.body == 'string' ? JSON.parse(response.body) : response.body;
    
    await t.expect(reponseBody.title).eql("testing");
    await t.expect(reponseBody.body).eql("automation Test Cafe");
    await t.expect(reponseBody.userId).eql(1);

    //console.log("Response Body :" + response);

})