const createTestCafe = require('testcafe');
 
let testcafe = null;
 
createTestCafe('localhost', 1337, 1338)
.then(tc => {
    testcafe=tc;
    const runner = testcafe.createRunner();
 
    return runner
    .src('tests/pageAction.ts')
    // .src('Testcase/*.ts')
    .browsers(['chrome'])
    .reporter([
        {name:'html',output:"reports/test-report.html"},
        {name:'json',output:"reports/test-report.json"}])
        .screenshots('screenshots',true)
    // .screenshots('screenshots',true,"screen1.png")
    // .concurrency(2)
    .run();
}).then(failedCount =>{
    console.log('Testsfailed' + failedCount);
 
    testcafe.close();
}).catch(error =>{
    console.error(error);
})