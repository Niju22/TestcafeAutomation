//import Selector form TestCafe
import { Selector } from "testcafe";

//creating a function with getElementsByXPath
const getElementsByXPath = Selector(xpath => {

    //this funciton uses document.evaluate to execute XPath query
    //XPathResult.UNORDERED_NODE_ITERATOR_TYPE allows iteration over all the mathching nodes/elements
    
    const iterator = document.evaluate(xpath,document,null,XPathResult.UNORDERED_NODE_ITERATOR_TYPE,null);

    const items :Node[] = [];
    //It collects all the elements into array usinng while loop and interateNext()
    let item = iterator.iterateNext();
    while(item)
    {
        items.push(item);
        item = iterator.iterateNext();
    }
    //this returns TestCafe to get all the elements with XPath
    return items
})

export default function(xpath)
{
    return Selector(getElementsByXPath(xpath));
}