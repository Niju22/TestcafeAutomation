
function threeNumber(x:number,y:number,z:number){
if (x >= y && x >= z) {
    console.log("The largest number is:", x);
} else if (y >= x && y >= z) {
    console.log("The largest number is:", y);
} else {
    console.log("The largest number is:", z);
}
}
threeNumber(6,11,1);