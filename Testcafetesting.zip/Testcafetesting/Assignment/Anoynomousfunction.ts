
let anonymousTes=function(){
console.log("Print the Internal Line")
}

anonymousTes();


console.log("========================")



let anonymousParameterTest = function(name1:string,name2:string):string
{
    return name1 + " " + name2;
}

let output:string  = anonymousParameterTest("Clinton","Roy");
console.log(output);