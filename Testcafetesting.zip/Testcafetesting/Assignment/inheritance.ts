class BaseClass
{
   
}

class Loginpage extends BaseClass
{
    
}

