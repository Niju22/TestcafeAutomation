class Gadgets
{
    series:number;
    mobilename:string;

    constructor(model:number,name:string)
    {
        this.series = model,
        this.mobilename = name;
    }
}

let gad:Gadgets = new Gadgets(16,"Iphone");
console.log(gad.mobilename)
console.log(gad.series)