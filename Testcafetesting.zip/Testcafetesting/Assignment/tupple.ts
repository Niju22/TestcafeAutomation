
let personDetails:[string,number]=["Haris",12345678];
console.log(personDetails[0])
console.log(personDetails[1])