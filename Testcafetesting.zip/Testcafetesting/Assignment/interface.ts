interface employeeDetails{
    name:string;
    department:string;
    age:number
}

let employee:employeeDetails={
    name:"Jackson Joe",
    department:"Testing",
    age:26
}

console.log(employee)