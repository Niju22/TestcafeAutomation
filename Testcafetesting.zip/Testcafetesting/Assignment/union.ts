
let uniondata:number|boolean|string
uniondata=3445;
uniondata=true;
uniondata="David"
