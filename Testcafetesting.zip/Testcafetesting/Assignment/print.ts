//	Write a program in TypeScript to print “Hello” 5 times


for(let i=1;i<=5;i++){
    console.log("Hello")
}
console.log("==========")

