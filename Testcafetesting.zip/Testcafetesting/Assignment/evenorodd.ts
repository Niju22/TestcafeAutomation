
function evenorOddvalue(num:number){
    if(num%2==0)
    {
        console.log("Enter Number"+" "+`${num}`+ " "+ "is Even")
    }else{
        console.log("Enter Number"+" "+`${num}`+ " "+ "is Odd")
    }
}
evenorOddvalue(84)