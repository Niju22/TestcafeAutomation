let Orderdetails=()=>{
    console.log("Ordered Details in Amazon")
}

Orderdetails();


// let amazonOrdered = (Mobile:string,Accessories:string) =>
//     {
//         console.log(Mobile + " " + Accessories);
    
//         return  + " " + lastName;
//     }
    
//     printFullName("","");