//Arrow Function without parameter

function arrowswithoutParameter(){
    console.log("Function without parameter")
}
arrowswithoutParameter();

//Anonymous Function without parameter

let anyarrowswithoutParameter=function (){
    console.log("Anonymous Function without parameter")
}
anyarrowswithoutParameter();

//Arrow Function without parameter

let arrowfunc= ()=>{
    console.log("Arrow Function without parameter")
}
arrowfunc()

//function with parameter

function arrowfuncParameter(fName:string){
    console.log(`${fName}`+"Arrow Function with parameter")
}
arrowfuncParameter("Niju")

//Anonymous function with parameter

let anarrowfuncParameter=function (fName:string){
    console.log(`${fName}`+"Arrow Function with parameter")
}
anarrowfuncParameter("David")

//Arrow Functions

let arrowParameters= (userName:string)=>{
    console.log(`${userName}`+" " +"Arrow function entered user name is")
}
arrowParameters("David Niju")

let arrowParameter= (userName:string,lastname:string):string=>{
    return userName+" "+lastname;
}
console.log(arrowParameter("David","Niju"))
