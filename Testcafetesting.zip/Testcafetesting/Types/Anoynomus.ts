//Anonymous function without parameter

let printMessage=function(){
    console.log("Anonymous test")
}

printMessage()

//Anonymous function with parameter

let anonyParameter=function (name:string){
    console.log(name+" "+"With Parameter")
}
anonyParameter("Test")

//Anonymous function with parameter and return 

let anoyreturn=function (firstName:string,LastName:string):string{
    console.log(`${firstName}`+`${LastName}`+"Anonymous function with parameter and return type")
    return firstName+""+LastName;
}

anoyreturn("David","Niju")