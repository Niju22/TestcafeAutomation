

//Declare String in Single Variable

let person:string="david";
console.log(person);

//Declare string in Multiple Line

console.log("==============");

let employee:string;
employee="David Niju";
console.log(employee);

//Number in single line

let age:number=23;
console.log(age);
console.log("==============");

let ages:number;
ages=34;

console.log(ages)

//boolean in single line

let isActive:boolean=true;
console.log(isActive);
console.log("==============");


let isComplete:boolean;
isComplete=false;
console.log(isComplete);

//Array in Single line

let rollNumber:number[]=[1,2,3,4];
console.log("Array in sinle line is:"+rollNumber);

//Array in Multiple line

let section:string[];
section=["Class A","Class B","Class C"]
console.log("Array for String:"+section)

//Tuples in Single Line

let details:[string,number,string,number]=["David",2400827,"ODC",4];
console.log(details);

//tuples in multi line

let employeeDetails:[string,number,number,string];
employeeDetails=["David Niju",827,4,"odc"]
console.log(employeeDetails);

//Enum for Numeric

enum weekdays{
    sunday=4,
    monday,
    tuesday,
    wednesday,
    thursday,
    friday,
    saturday,
}

console.log(weekdays)

//Enum for String


enum month{
    First_Month="January",
    Second_Month="February",
    Third_Month="March",
    Fouth_Month="April"
}
console.log(month)

//Type Inference in single line

let phnoneNumber=123456789;
console.log(phnoneNumber)

//Type Inference in multiple line

let nativePlace="Madurai";
console.log(nativePlace);

//Object

let employees:object;
employees={
    firstName:"david",
    employeeAge:25,
    designation:"QA",
}
console.log(employees)

//Any in Single line

let state:any;
state=628701;
console.log(state)

//Any in Multiple line

let salaryStructure:any="Revised Salary Structure in Organization";
salaryStructure=344;
salaryStructure=true;
console.log(salaryStructure);


//void

let testing:void;
// testing="Typescript";
// testing=34;
// testing=true;
testing=undefined;
console.log(testing);

let testingvoid:void=undefined;
console.log(testingvoid);

//Never 

let nevertest:never;
// nevertest=null;
// nevertest="dasd";
// nevertest=undefined;


//Object in Single line

let personDetail:object={
    personName:"David",
    personAge:25,
    personId:1510
}
console.log(personDetail)

//Object in Multiple line

let personDetails:object;
personDetails={
    personName:"David",
    personAge:25,
    personId:1510
}
console.log(personDetails)


//undefined in multiple line

let undef:undefined;
undef=undefined;
// undef=never;
// undef=boolean
// undef=23
// undef="David";
console.log(undef)









