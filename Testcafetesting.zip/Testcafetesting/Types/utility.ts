interface criticalEmployee{
    userName:string;
    userId:number;
    userLocation:string
}

// let emp:Partial<criticalEmployee>={
//     userName:"David",
//     userId:15
// }
// console.log(emp.userId)

// let emp:Required<criticalEmployee>={
//     userName:"David",
//     userId:15,
//     userLocation:"Cbe"
// }
// console.log(emp.userId)
// console.log(emp.userName)
// console.log(emp.userLocation)

// let emp:Omit<criticalEmployee,'userId'|'userName'>={
//     userLocation:"Coimbatore",
// }
// console.log(emp.userLocation)

// let emp:Pick<criticalEmployee,'userId'|'userName'>={
//     userId:23,
//     userName:"ccc"
// }

let emp:Pick<criticalEmployee,'userId'>={
    userId:23,
}
console.log(emp.userId)

