function overload(username:string,userpass:string):string;
function overload(username:number,userpass:string):string;
function overload(username:boolean,userpass:number):string;

function overload(username:any,userpass:any):any{
    return username+userpass;

}

console.log(overload("Dav","233344"))
console.log(overload(true,234))
console.log(overload(12,"testing"))
