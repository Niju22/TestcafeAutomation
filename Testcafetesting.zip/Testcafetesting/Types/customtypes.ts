type phonenumber=number

let contact:phonenumber=987654321;
console.log(contact)