

// function findLength(abc:string)
// {
//     if(abc.length){
//         console.log("pass");
//     }
//     else{
//         console.log("fail");
//     }
// }
// findLength("cts");


// //Function With Multiple parameters aF2 FT CRV SC

// function multdata(x:number,y:number):number{
// return x*y;
// }

// console.log(multdata(3,2));

//Function with option parameters

//nFS,G?FS FT CRV SC


// function optionalParameter(name:string,greeting?:string):string{
//     return '${greeting||"hello"},${name}!';
// }
// console.log(optionalParameter("test"));


//Syntax for String

let Name:string ="david";

//Syntax for Number

let age:number=24;

//Syntax for boolean

let isActive:boolean=true;
let isComplete:boolean=false;

//Syntax for Array

let weekDays:number[]=[1,2,3,4,5,6,7];


//syntax for Tupples

let person:[string,number]=["apple",23];

//Syntax 



function multiply(x:number,y:number=3):number
{
return x*y;
}

let result:number=multiply(2,3);
console.log(result);

