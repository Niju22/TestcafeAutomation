class Baseclass{
    studentname:string
}

class childclass extends Baseclass{
    studentrollno:number

    getstudentrollno(){
        return this.studentrollno
    }
}

let c:childclass= new childclass();
c.getstudentrollno()