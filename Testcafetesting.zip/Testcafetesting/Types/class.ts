// class studentDetails{
//     personName:string;
//     age:number;
//     rollNo:number

//     constructor(){
//         this.age=23;
//         this.personName="david";
//         this.rollNo=15
//     }
    
// }

// let s:studentDetails=new studentDetails();
// console.log(s.age)
// console.log(s.personName)
// console.log(s.rollNo)

console.log("=================")

class employeeDetails{
    employeeName:string;
    employeeId:number;
    employeeOrganization:string

    constructor(userName:string,id:number,organization:string){
        this.employeeId=id;
        this.employeeName=userName;
        this.employeeOrganization=organization;
  
}}

let empl:employeeDetails = new employeeDetails("David",12,"cts");
console.log(empl.employeeId)
console.log(empl.employeeName)
console.log(empl.employeeOrganization)