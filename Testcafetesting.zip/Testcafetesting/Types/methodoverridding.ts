class baseclass{
    testmethod(){
        console.log("Method from the baseclass")
    }
}

class Childclass extends baseclass{
    testmethod() {
        console.log("Method from the Child Class")
    }
}

let ch:Childclass=new Childclass();
ch.testmethod();
let b:baseclass=new baseclass();
b.testmethod()

let b1:baseclass=new Childclass();
b1.testmethod();


