let personalInformation:string|number

personalInformation="David";
personalInformation=23456;
// personalInformation=true;

console.log(personalInformation)