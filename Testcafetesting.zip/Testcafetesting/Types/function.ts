//Function without parameter

function clickde(){
    console.log("Function without parameter")
}

clickde();

//Function with parameter


function enterName(name:string){
    console.log(`${name}`+":user entered name is")
}

enterName("David");


//Function with parameter and return type

function userCredential(name:string,password:string):string{
    console.log("Function with parameter and return type")
return name+password;
}

let result:string=userCredential("David","1234566")
console.log(result)

//Rest Parameter

function restParamet(...number:number[]):number{
    return number.reduce((adding,sundr) =>adding+sundr+0);
}

console.log(restParamet(1,5,4));