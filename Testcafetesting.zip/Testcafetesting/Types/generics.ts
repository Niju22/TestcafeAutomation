// function testinggeneric(testing:any):any{
//     return testing;
// }
// testinggeneric("david");
// testinggeneric(23);
// testinggeneric(false);
// console.log(testinggeneric(false))


function identify<T>(testing:T):T{
    return testing;
}

console.log(identify(2));
console.log(identify(false));
console.log(identify("testing"));


