

let twoDimension:number[][]=[[1,0,4],[3,4,8],[5,6,9]];

for(let i=0;i<twoDimension.length;i++){

    for(let j=0;j<twoDimension[i].length;j++){
    
        // console.log([i][j]); 
        console.log(twoDimension[i][j]+"");  //printing the elements
        // console.log( i); //printing the values
        
    }
    }

    console.log("Final Line...")


