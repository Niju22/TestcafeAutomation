let list:number[]=[23,45,45];
console.log(list)
console.log(list[1])
console.log(list.length);


let fruits:string[]=["Apple","Mango","Orange"];
console.log(fruits)
console.log(fruits[1])
console.log(fruits.length);

let fruits1:string[]=["Grapes","Strawberry","Blueberry"];
for(let n of fruits1){
    console.log(n);
}