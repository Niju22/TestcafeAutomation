let jobs:[string,number,string]=["David",5,"CTS"]
console.log(jobs)
console.log(jobs[0])
console.log(jobs.length)
