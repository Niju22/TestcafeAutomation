import { Selector } from "testcafe";
import Commondatapage from "../Pages/Commondatapage";
import Loginpage from "../Pages/Loginpage";

const navig=new Commondatapage()
const login=new Loginpage()

fixture('Login Functionality Scneario')
.page ('http://zero.webappsecurity.com/')

test('Login with valid crdentials',async t=>{
   navig.siginNavigation
   login.enterUsername("username")
   login.enterPassword("password")
   login.submit

   await t.expect()
})




