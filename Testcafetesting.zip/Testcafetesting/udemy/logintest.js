// import { Selector } from "testcafe";
// import loginfunctionality from "../Pages/Loginpage";

// const login =new Loginpage()

// fixture( "Login Test").page("http://zero.webappsecurity.com/")

// test("Valid Credentials",async t=>{
//     await t.click(login.loginbutton)
//     await t.click(login.username).typeText("david",{paste})
//     await t.click(login.userpassword).typeText("testpassword")
//     await t.click(login.submitbutton)

// })
