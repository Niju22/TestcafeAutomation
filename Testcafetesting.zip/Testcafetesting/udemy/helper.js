// import {l} from "testcafe";

// export async function logincredentials(username,password){
//       await l.click("#signin_button")
//       await l.typeText("#user_login",username)
//       await l.typeText("#user_password",password)
//       await l.click(".btn-primary")

// }