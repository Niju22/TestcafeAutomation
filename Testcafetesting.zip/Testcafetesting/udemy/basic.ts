import { Selector } from 'testcafe'


fixture('Getting Started with Testcafe')
.page ('https://devexpress.github.io/testcafe/example/')
.before(async t=>{

})
.beforeEach(async t=>{
    await t.setTestSpeed(1)
    // await t.setPageLoadTimeout(0)
})
.after(async t=>{

})
.afterEach(async t=>{

})


// test.skip()
// test.only()

test.skip('My First test',async t =>{
    

    const developer_name=Selector('#developer-name')
    const submit_form=Selector('#submit-button')
    const article_Text=Selector('#article-header').innerText

     // await t.wait(3000)  //pausing the element
    // await t.takeScreenshot({fullPage:true}) //full webelement
    // await t.takeElementScreenshot(submit_form) //specific webelement

    await t.typeText(developer_name,"testing")
   
    await t.click(submit_form)

    await t.expect(article_Text).contains("testing")

    //Actions Api

    await t.click('selector',{ options}) //click
    await t.doubleClick('selector',{options}) //double click
    await t.drag('selector',200,250,{options})  //drag 
    await t.hover('selector',{options}) //hover
    await t.selectText('selector') //selecting the text
    await t.typeText('selector','text') //Typing or sendkeys
    await t.pressKey('enter') //keyboard actions
    await t.navigateTo('url') //url navigation
    await t.takeScreenshot({fullPage:true}) //full webelement
    await t.takeElementScreenshot(submit_form) //specific webelement -->submit_form--webelement
    await t.resizeWindow(1400,1030) //resizing the browser


    //Api Assertion

    await t.expect('tester').eql('tester','Text is not equal',options) //Assertion Equal
    await t.expect('tester').notEql('manual','Enter text is same',options) //Assertion Not Equal
    await t.expect(true).ok('Condition is satisfied',options) //Assertion true
    await t.expect(true).notOk('Condition is not satisfied',options) //Assertion False
    await t.expect("test").contains("testing manual") //Conatins Assertion
    await t.expect("testing").notContains("automation") //Not contains assertion
    await t.expect(5).gt(5) //Greater,,it should fail
    await t.expect(12).gte(12) //Greater or Equal,,it should pass
    await t.expect(5).lt(5) //lesser,it should fail
    await t.expect(12).lte(12) //lesser or Equal,it should pass
    await t.expect(10).within(1,100) //within range assertion it should pass
    await t.expect(10).notWithin(5,50) //not within range assertion it should pass

 // const inputfieldxpath="//*[@id='submit'"
    // const inputfieldcss=xpathToCss(inputfieldxpath)    xpath to invoke the element
    // await l.click(inputfieldcss)

// Script
// "test:chrome:5": "testcafe -c 5 chrome ./tests -s takeOnFails=true --disable-page-caching",
//     "test:chrome:headless": "testcafe chrome:headless ./tests -s takeOnFails=true",
//     "test:chrome:headless:5": "testcafe -c 5 chrome:headless ./tests -s takeOnFails=true",
//     "test:chrome:mobile": "testcafe chrome:emulation:device=iphone 12 ./tests -s takeOnFails=true",
//     "test:edge": "testcafe edge ./tests -s takeOnFails=true",
//     "test:multiple": "testcafe chrome,edge ./test -s takeOnFails=true --disable-page-caching"

})
