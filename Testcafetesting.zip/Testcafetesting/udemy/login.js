// import { Selector } from "testcafe";
// import { logincredentials } from "./helper";
// import xpathToCss from "xpath-to-css"



// fixture("Login Test").page("http://zero.webappsecurity.com/")
// test.before("Login Test With Valid Credentials",async l=>{

//    const click_siginbutton= Selector("#signin_button")
  

//     // // await l.click("#signin_button")
//     // await l.typeText("#user_login","username")
//     // await l.typeText("#user_password","password")
//     // await l.click(".btn-primary")
//     // Selector("a").withText

//     await logincredentials("username","password")
// })("Adding payment details",async p=>{

//     await l.click(Selector("a").withText("is pasword forgetten"))
//     await l.pressKey("enter")
//     await l.click(Selector("input").withAttribute("value","send mesage"))

//     // const inputfieldxpath="//*[@id='submit'"
//     // const inputfieldcss=xpathToCss(inputfieldxpath)    xpath to invoke the element
//     // await l.click(inputfieldcss)
// })




