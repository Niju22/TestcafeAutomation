let agelimitation:number=65;


if(agelimitation<21)
{
    console.log("Not Eligible for License");

}else if(agelimitation>=21 && agelimitation<=54)
{
    console.log("Eligible for license")
}
else if(agelimitation>=55 && agelimitation<=65){
    console.log("Need to take medical certificate for taking license")
}else if(agelimitation>=66){
    console.log("Not advisible to drive")
}
