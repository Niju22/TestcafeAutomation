let agee: number = 17;
let canVote: string = agee >= 18 ? "Yes" : "No";
console.log(canVote);