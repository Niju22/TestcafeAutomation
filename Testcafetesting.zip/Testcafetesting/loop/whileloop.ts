let count =10;

while(count<=15)
{
    console.log(count)

    count++;
}

console.log("Final Line");


// let i=1;
// let n=10;

// while(n>i){
//     console.log(n)
//     n--;
// }