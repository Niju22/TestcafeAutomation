// let names:number=5;

// for(let i=0;i<names;i++)
// {
//     console.log(i);
// } 


// let sum:number=0;
// let n:number=1000;

// for (let i=0;i<n;i++)
// {
//    console.log(sum+i);
// }

// let sum:number=0;
// let n:number=100;

// for(let i=n;i>=1;i--)
// {
//     console.log(sum-i);
// }


// //Print 1 to 15 Numbers

// for (let i=1;i<=15;i++){
//     console.log("Iteration:"+i);

// }

// console.log("==================");

// //Print 10 to 1 Numbers

// for (let i=10;i>=1;i--)
// {
//     console.log("Iteration:"+i);  
// }

let curr:number=2;
let sum:number=0;
let dig:number=20;


for (let i = 1; i <= dig; i++) {
    sum += curr;

    // next even number
    curr += 2;

    console.log(i)
}