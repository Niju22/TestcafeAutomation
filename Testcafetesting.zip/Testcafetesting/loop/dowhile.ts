
let num = 2;
do
{
    console.log(num);

    num++;

} while(num<=5);