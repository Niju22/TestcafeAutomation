let names:string[]=["David","Niju","S.F"]
for(let n of names){
    console.log(n)
    console.log(n.length)
}