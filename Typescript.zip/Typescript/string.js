var FirstName = 'Sachin'; //creating a variable and assigning value to variable in single line
var last_Name = "Tendulkar";
var grade = 'C';
var grade1 = "d";
var name1; //create a variable
name1 = "Dravid"; //assign the value
console.log(name1);
name1 = "Dhoni";
console.log(name1);
console.log(typeof (name1));
