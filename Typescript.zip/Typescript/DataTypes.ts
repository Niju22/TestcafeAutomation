

//Declare String in Single Variable

let person:string="david";
console.log("Declare String in single line:"+person);

//Declare string in Multiple Line


let employee:string;
employee="David Niju";
console.log("Declare String in single line:"+employee);

//Number in single line

let age:number=23;
console.log("Declare Number in single line:"+age);


let ages:number;
ages=34;

console.log("Declare Number in Multiple line:"+ages)

console.log("==============");

//boolean in single line

let isActive:boolean=true;
console.log("Declare Boolean syntax:"+isActive);



let isComplete:boolean;
isComplete=false;
console.log(isComplete);

console.log("==============");

//Array in Single line

let rollNumber:number[]=[1,2,3,4];
console.log("Array in sinle line is:"+rollNumber);

//Array in Multiple line

let section:string[];
section=["Class A","Class B","Class C"]
console.log("Array for String:"+section)


console.log("========================")

//Tuples in Single Line

let details:[string,number,string,number]=["David",2400827,"ODC",4];
console.log("Declare Tuple in single line:"+details);

//tuples in multi line

let employeeDetails:[string,number,number,string];
employeeDetails=["David Niju",827,4,"odc"]
console.log("Declare tuple in multiple line:"+employeeDetails);

console.log("===================")

//Enum for Numeric

enum weekdays{
    sunday=4,
    monday,
    tuesday,
    wednesday,
    thursday,
    friday,
    saturday,
}

console.log(weekdays)

console.log("Declare enum rearranged value:"+weekdays)

enum weekday{
    sunday,
    monday,
    tuesday,
    wednesday,
    thursday,
    friday,
    saturday,
}

console.log("Declare enum for ordered value:"+weekday)
console.log("Enum for Particular Weekday value:"+weekday.friday)




//Enum for String


enum month{
    First_Month="January",
    Second_Month="February",
    Third_Month="March",
    Fouth_Month="April"
}
console.log(month)

console.log("Declare enum for String ordered value:"+weekday)


console.log("====================")

//Type Inference in single line

let phnoneNumber=123456789;
console.log(phnoneNumber)

//Type Inference in multiple line

let nativePlace="Madurai";
console.log("Type inference:"+nativePlace);


console.log("====================")

//Any in Single line

let state:any;
state=628701;
console.log(state)

//Any in Multiple line

let salaryStructure:any="Revised Salary Structure in Organization";
salaryStructure=344;
salaryStructure=true;
console.log(salaryStructure);


console.log("====================")


//void

let testing:void;
// testing="Typescript";
// testing=34;
// testing=true;
testing=undefined;
console.log(testing);

let testingvoid:void=undefined;
console.log("Declare void syntax:"+testingvoid);

console.log("====================")

//Never 

let nevertest:never;
// nevertest=null;
// nevertest="dasd";
// nevertest=undefined;



console.log("====================")
