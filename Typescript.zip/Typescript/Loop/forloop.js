// let names:number=5;
// for(let i=0;i<names;i++)
// {
//     console.log(i);
// } 
// let sum:number=0;
// let n:number=1000;
// for (let i=0;i<n;i++)
// {
//    console.log(sum+i);
// }
var sum = 0;
var n = 100;
for (var i = n; i >= 1; i--) {
    console.log(sum - i);
}
