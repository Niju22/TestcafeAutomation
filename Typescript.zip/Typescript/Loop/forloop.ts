// let names:number=5;

// for(let i=0;i<names;i++)
// {
//     console.log(i);
// } 


// let sum:number=0;
// let n:number=1000;

// for (let i=0;i<n;i++)
// {
//    console.log(sum+i);
// }

let sum:number=0;
let n:number=100;

for(let i=n;i>=1;i--)
{
    console.log(sum-i);
}