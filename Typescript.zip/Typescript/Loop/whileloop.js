var count = 10;
while (count >= 5) {
    console.log(count);
    count--;
}
console.log("Final Line");
var i = 1;
var nn = 10;
while (nn > i) {
    console.log(nn);
    nn--;
}
