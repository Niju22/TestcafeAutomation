let fruits:string[]=["Apple","Mango","Orange"]
for(let n of fruits)
{
console.log(n);
}


// let names:string[] = ["Sachin","Dravid","Dhoni","Sehwag","Yuvraj"];

// for(let n of names)
// {
//     console.log(n);
// }