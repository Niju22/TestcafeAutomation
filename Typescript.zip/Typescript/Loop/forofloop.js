var fruits = ["Apple", "Mango", "Orange"];
for (var _i = 0, fruits_1 = fruits; _i < fruits_1.length; _i++) {
    var n = fruits_1[_i];
    console.log(n);
    // console.log("=================");
    // console.log(n.length);
    console.log(n[0]);
}
// let names:string[] = ["Sachin","Dravid","Dhoni","Sehwag","Yuvraj"];
// for(let n of names)
// {
//     console.log(n);
// }
