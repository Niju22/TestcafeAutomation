let count =10;

while(count>=5)
{
    console.log(count)

    count--;
}

console.log("Final Line");


let i=1;
let nn=10;

while(nn>i){
    console.log(nn)
    nn--;
}