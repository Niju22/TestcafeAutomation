let serial:number=6
do{
    console.log(serial+":Iteration")
    serial++;
}while(serial<=5)