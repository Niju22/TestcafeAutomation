let FirstName : string = 'Sachin';//creating a variable and assigning value to variable in single line
let last_Name: string = "Tendulkar";
let grade:string = 'C';
let grade1:string = "d";

let name1:string;//create a variable
name1="Dravid";//assign the value
console.log(name1);
name1="Dhoni";
console.log(name1);

console.log(typeof(name1));
