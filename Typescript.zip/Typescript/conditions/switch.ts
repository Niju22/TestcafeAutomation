//interview block arrangements


let sdb:number;
sdb=5;

switch(sdb)
{
    case 1:
        console.log("Go Straight and take left")
        break;
        case 2:
            console.log("Go Left and take Right") 
            break;
            case 3:
                console.log("Go Straight ")
                break;

                default:
                    console.log("Given SDB Is not available,Please check correct details")

}



