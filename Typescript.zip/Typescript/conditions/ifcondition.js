var id = 5;
if (id = 5) {
    console.log("Print the id value");
}
console.log("Out of code");
