//Election Age Restriction
var Age = 18;
if (Age >= 18) {
    console.log("India Citizen is Eligible to Vote");
}
else
    console.log("Not Eligible");
