//Declare String in Single Variable
var person = "david";
console.log("Declare String in single line:" + person);
//Declare string in Multiple Line
var employee;
employee = "David Niju";
console.log("Declare String in single line:" + employee);
//Number in single line
var age = 23;
console.log("Declare Number in single line:" + age);
var ages;
ages = 34;
console.log("Declare Number in Multiple line:" + ages);
console.log("==============");
//boolean in single line
var isActive = true;
console.log("Declare Boolean syntax:" + isActive);
var isComplete;
isComplete = false;
console.log(isComplete);
console.log("==============");
//Array in Single line
var rollNumber = [1, 2, 3, 4];
console.log("Array in sinle line is:" + rollNumber);
//Array in Multiple line
var section;
section = ["Class A", "Class B", "Class C"];
console.log("Array for String:" + section);
console.log("========================");
//Tuples in Single Line
var details = ["David", 2400827, "ODC", 4];
console.log("Declare Tuple in single line:" + details);
//tuples in multi line
var employeeDetails;
employeeDetails = ["David Niju", 827, 4, "odc"];
console.log("Declare tuple in multiple line:" + employeeDetails);
console.log("===================");
//Enum for Numeric
var weekdays;
(function (weekdays) {
    weekdays[weekdays["sunday"] = 4] = "sunday";
    weekdays[weekdays["monday"] = 5] = "monday";
    weekdays[weekdays["tuesday"] = 6] = "tuesday";
    weekdays[weekdays["wednesday"] = 7] = "wednesday";
    weekdays[weekdays["thursday"] = 8] = "thursday";
    weekdays[weekdays["friday"] = 9] = "friday";
    weekdays[weekdays["saturday"] = 10] = "saturday";
})(weekdays || (weekdays = {}));
console.log(weekdays);
console.log("Declare enum rearranged value:" + weekdays);
var weekday;
(function (weekday) {
    weekday[weekday["sunday"] = 0] = "sunday";
    weekday[weekday["monday"] = 1] = "monday";
    weekday[weekday["tuesday"] = 2] = "tuesday";
    weekday[weekday["wednesday"] = 3] = "wednesday";
    weekday[weekday["thursday"] = 4] = "thursday";
    weekday[weekday["friday"] = 5] = "friday";
    weekday[weekday["saturday"] = 6] = "saturday";
})(weekday || (weekday = {}));
console.log("Declare enum for ordered value:" + weekday);
console.log("Enum for Particular Weekday value:" + weekday.friday);
//Enum for String
var month;
(function (month) {
    month["First_Month"] = "January";
    month["Second_Month"] = "February";
    month["Third_Month"] = "March";
    month["Fouth_Month"] = "April";
})(month || (month = {}));
console.log(month);
console.log("Declare enum for String ordered value:" + weekday);
console.log("====================");
//Type Inference in single line
var phnoneNumber = 123456789;
console.log(phnoneNumber);
//Type Inference in multiple line
var nativePlace = "Madurai";
console.log("Type inference:" + nativePlace);
console.log("====================");
//Any in Single line
var state;
state = 628701;
console.log(state);
//Any in Multiple line
var salaryStructure = "Revised Salary Structure in Organization";
salaryStructure = 344;
salaryStructure = true;
console.log(salaryStructure);
console.log("====================");
//void
var testing;
// testing="Typescript";
// testing=34;
// testing=true;
testing = undefined;
console.log(testing);
var testingvoid = undefined;
console.log("Declare void syntax:" + testingvoid);
console.log("====================");
//Never 
var nevertest;
// nevertest=null;
// nevertest="dasd";
// nevertest=undefined;
console.log("====================");
